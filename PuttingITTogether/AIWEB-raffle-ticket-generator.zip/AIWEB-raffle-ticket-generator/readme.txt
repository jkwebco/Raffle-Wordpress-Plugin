=== AIWEB Raffle Ticket Generator - Woocommerce ===
Contributors: AIWEB
Donate link: http://aiweb.biz
Tags: woocommerce, raffle
Requires at least: 3.0.1
Tested up to: 5.0
Stable tag: 5.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is used with WooCommerce to generate raffle ticket numbers that are emailed to customers.


== Description ==

The free version of this plugin generates 500 unique raffle ticket numbers and then recycles.  It starts with ticket number 100 and increments each ticket number by 1 until 599.  The 501st ticket will be assigned number 100 again and so on.  This is designed for small raffles.  Upon completing checkout in WooCommerce, the customer is emailed the ticket numbers.

To setup the raffle, simple install the plugin as described below.  Then create a product in WooCommerce and put in the number of raffle tickets for the product.  Example, if you put 5 in the number of tickets field, that product will generate 5 tickets.  

Informational videos and FAQs are can be found at http://aiweb.biz



== Installation ==

1. Upload `raffle-ticket-generator.zip` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Can I define a custom raffle ticket number format? =

Not with this version. 

= Does this allow me to sell unlimited tickets? =

Yes, although the numbers recycle after the first 500 tickets, so there are only 500 unique numbers.  


= Is this a trial version of the paid full feature editions? =

No, this is simple version for small raffles.  This is not a trial of our full featured editions.

= Can I remove the branding from the order emails? =

Not with this version. 

== Upgrade notice ==
The previous versions allowed for 100 unique numbers, we have increased that to 500 and have added an export feature

== Screenshots ==

1. This screenshot shows the product configuration in WooCommerce.  When the plugin is installed, the product editor will show a "Number of Raffle Tickets" field.  Leave it blank for normal products without a raffle ticket, if you want it to be a raffle ticket item, then put in the appropriate number.  In this example it is 50 - this product will generate 50 tickets.

== Changelog ==

= 1.0.1 =

Changed numbers from 100-199.


